from django.apps import AppConfig


class GithubFetcherConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'github_fetcher'
